export const data = {
  name: 'Chat Bot',
  title: 'Lorem, ipsum',
  avatar: '/chat-bot-logo.png',
  color: '',
  theme: '',
}
